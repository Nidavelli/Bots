# Why Dbots?
All the bots are specifically designed to work on Deriv's DBot platform with AI technology, which you can access by <b><a href="https://dboty.com/Deriv-github">creating an account</a></b> or <b><a href="https://dboty.com/Deriv-github">by becoming a partner</a></b>. Remember, "Game theory rules everything. So come to the game."

Check this playlist about how we turn $100 to approximately $300 =>> <b><a href="https://www.youtube.com/watch?v=ZlH-tWCum74&list=PLGPX9PHIb5CV2QyhnFFqy1ypHnUoaXJA9&pp=gAQBiAQB">Click to watch on YouTube</a></b>



Before Downloading all the free Dbots, Follow these steps to get started:

# Steps
<b><a href="https://dboty.com/Deriv-github">Sign up for Deriv Dbot</a></b>

<b><a href="https://dboty.com/Deriv-github">Log in to your Dbot account</a></b>

<b><a href="https://dboty.com/Deriv-github">Navigate to the Dbot AI auto-trading area: bot.deriv.com</a></b>

<a href="https://github.com/DerivBots/Free-Dbots/archive/refs/heads/main.zip">Download all of our bots here</a>

Upload the bot you want to use in Dbot

Click "Run" to get started to see the results

<b>(Test all new Dbots files to Demo account before going to the real account)</b>
  
  You can welcome to check our <b><a href="https://dboty.com">Dbot Website</a></b>, where we are posing many Free and premium Deriv Dbots each Week.
  
  Best regards, A Dbot Developer
